package com.demo.EmployeeMgmtSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeMgmtSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
